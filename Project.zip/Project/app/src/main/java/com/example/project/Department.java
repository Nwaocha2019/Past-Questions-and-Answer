package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextClock;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Department extends AppCompatActivity {

    private ListView listview;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);

        textView = (TextView) findViewById(R.id.depts);
        listview = (ListView) findViewById(R.id.dept_list);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Computer Science  -->");

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.list_color_white, arrayList);
        listview.setAdapter(arrayAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(Department.this, Courses.class);
                startActivity(intent);
            }
        });
    }
}
