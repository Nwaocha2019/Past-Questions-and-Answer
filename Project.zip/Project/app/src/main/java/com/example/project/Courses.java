package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Courses extends AppCompatActivity {

    private ListView listview;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        textView = (TextView) findViewById(R.id.course);
        listview = (ListView) findViewById(R.id.course_list);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("CSC 101 - Intro. to Computer   ->");
        arrayList.add("CSC 102 - Intro. to Problem Solving ->");
        arrayList.add("CSC 201 - Computer Programming I   ->");
        arrayList.add("CSC 202 - Computer Programming II   ->");
        arrayList.add("CSC 203 - Fundamentals of Data Structure ->");
        arrayList.add("CSC 204 - Computer Hardware   ->");
        arrayList.add("CSC 205 - Discrete Structure  ->");
        arrayList.add("CSC 206 - Foundations of Sequential Program  ->");
        arrayList.add("CSC 207 - Operating System  ->");
        arrayList.add("CSC 301 - Structured Programming  ->");
        arrayList.add("CSC 302 - Compiler Construction I  ->");
        arrayList.add("CSC 303 - Object-Oriented Programming  ->");
        arrayList.add("CSC 304 - Computational Science and Numerical Methods  ->");
        arrayList.add("CSC 305 - Operating Systems II  ->");
        arrayList.add("CSC 306 - Computer Architecture and Organization II  ->");
        arrayList.add("CSC 307 - Computer Architecture and Organization I  ->");
        arrayList.add("CSC 308 - Algorithms and Complexity Analysis  ->");
        arrayList.add("CSC 309 - Database Management  ->");
        arrayList.add("CSC 310 - Systems Analysis and Design  ->");
        arrayList.add("CSC 311 - Survey of Programming Languages  ->");




        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.list_color_yellow, arrayList);
        listview.setAdapter(arrayAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(Courses.this, CSC_101.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(Courses.this, CSC_102.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(Courses.this, CSC_201.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(Courses.this, CSC_202.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(Courses.this, CSC_203.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(Courses.this, CSC_204.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(Courses.this, CSC_205.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(Courses.this, CSC_206.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(Courses.this, CSC_207.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(Courses.this, CSC_301.class);
                    startActivity(intent);
                }
                if (position == 10) {
                    Intent intent = new Intent(Courses.this, CSC_302.class);
                    startActivity(intent);
                }
                if (position == 11) {
                    Intent intent = new Intent(Courses.this, CSC_303.class);
                    startActivity(intent);
                }
                if (position == 12) {
                    Intent intent = new Intent(Courses.this, CSC_304.class);
                    startActivity(intent);
                }
                if (position == 13) {
                    Intent intent = new Intent(Courses.this, CSC_305.class);
                    startActivity(intent);
                }
                if (position == 14) {
                    Intent intent = new Intent(Courses.this, CSC_306.class);
                    startActivity(intent);
                }
                if (position == 15) {
                    Intent intent = new Intent(Courses.this, CSC_307.class);
                    startActivity(intent);
                }
                if (position == 16) {
                    Intent intent = new Intent(Courses.this, CSC_308.class);
                    startActivity(intent);
                }
                if (position == 17) {
                    Intent intent = new Intent(Courses.this, CSC_309.class);
                    startActivity(intent);
                }
                if (position == 18) {
                    Intent intent = new Intent(Courses.this, CSC_310.class);
                    startActivity(intent);
                }
                if (position == 19) {
                    Intent intent = new Intent(Courses.this, CSC_311.class);
                    startActivity(intent);
                }

            }
        });
    }
}
