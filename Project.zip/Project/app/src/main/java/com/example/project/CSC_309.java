package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CSC_309 extends AppCompatActivity {

    private TextView t1, t2, t3, t4;
    private Button btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_csc_309);

        t1 = (TextView) findViewById(R.id.csc_309);
        t2 = (TextView) findViewById(R.id.csc_309_cd);
        t3 = (TextView) findViewById(R.id.csc_309_underline);
        t4 = (TextView) findViewById(R.id.csc_309_content);

        btn1 = (Button) findViewById(R.id.csc_309_show_questions);
        btn2 = (Button) findViewById(R.id.csc_309_show_answers);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CSC_309.this, CSC_309_SHW_Q.class);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CSC_309.this, CSC_309_SHW_A.class);
                startActivity(intent);
            }
        });
    }
}
